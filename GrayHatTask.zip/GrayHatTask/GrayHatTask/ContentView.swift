//
//  ContentView.swift
//  GrayHatTask
//
//  Created by Macbook on 31/03/2023.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        HomeView(viewModel: WatchesView())
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .previewDevice("iphone 12 Pro Max")
    }
}
