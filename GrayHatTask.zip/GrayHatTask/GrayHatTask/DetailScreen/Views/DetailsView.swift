//
//  DetailsView.swift
//  GrayHatTask
//
//  Created by Macbook on 31/03/2023.
//

import SwiftUI

struct DetailsView: View {
    
    @State private var isShowAlert = false
    @Environment(\.presentationMode) var mode
    
    var body: some View {
        ScrollView {
            
            topContent
            
            VStack(alignment: .leading){
                
                priceDetail
                
                Spacer()
                
                colorView
                
                Spacer()
                
                description
                
                cartButton
            }
            
        }
//        .edgesIgnoringSafeArea(.top)
        .navigationBarHidden(true)
    }
}

struct DetailsView_Previews: PreviewProvider {
    static var previews: some View {
        DetailsView()
    }
}





extension DetailsView {
    
    var topContent: some View {
        ZStack(alignment: .top){
            Image("image")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: .infinity, height: 350, alignment: .center)
                .clipped()
            
            HStack{
                Button(action: {
                    mode.wrappedValue.dismiss()
                }, label: {
                        Image(systemName: "arrow.left")
                            .resizable()
                            .clipped()
                            .frame(width: 20, height: 20)
                            .padding()                })
                Spacer()
                
                Button{
                    
                } label : {
                    Image(systemName: "heart")
                        .resizable()
                        .clipped()
                        .frame(width: 20, height: 20)
                        .padding()
                }
            }
            .padding()
            .foregroundColor(.black)
        }
    }
    
    var colorView: some  View{
        VStack(alignment: .leading) {
            Text("Colors")
                .fontWeight(.semibold)
                .font(.title2)
            
            HStack {
                HStack{
                    Circle()
                        .foregroundColor(.pink)
                        .frame(width: 50, height: 40)
                    
                    Text("Chalk pink")
                        .foregroundColor(.gray)
                }
                .frame(width: 150, height: 60)
                .background(Color(.systemFill))
                .cornerRadius(10)
                
                HStack{
                    Circle()
                        .foregroundColor(.gray)
                        
                        .frame(width: 50, height: 40)
                    
                    Text("dark order")
                        .foregroundColor(.gray)
                }
                .frame(width: 150, height: 60)
                .background(Color(.systemFill))
                .cornerRadius(10)
            }
        }
        .padding(.horizontal)
    }
    
    var priceDetail : some View{
        VStack{
            HStack{
                VStack(alignment: .leading) {
                    Text("Apple Watch Series")
                        .font(.title2)
                        .fontWeight(.semibold)
                    
                    Text("(with solo app)")
                        .foregroundColor(.gray)
                }
                
                Spacer()
                
                Text("$1200")
                    .font(.title)
                    .foregroundColor(.purple)
            }
            
        }
        .padding()
    }
    
    var description: some View{
        VStack(alignment: .leading){
            Text("Detail")
                .foregroundColor(.gray)
                .font(.title2)
                .padding(.top)
            
            Text("It's a simple fix. When you pass an array to List, the elements in the array need to conform to the Identifiable protocol. String does not conform to Identifiable, so the way to make this work is to use")
                .frame(height: 130)
                .padding(.top)
            
        }
        .padding(.horizontal)
    }
    
    var cartButton: some View {
        Button(action: {
            isShowAlert = true
        }, label: {
            Text("Add to cart")
                .font(.title2)
                .fontWeight(.bold)
                .foregroundColor(.white)
                .frame(height: 70)
                .frame(maxWidth: 350)
                .background(Color.blue)
                .cornerRadius(10)
        }).alert(isPresented: $isShowAlert, content: {
            Alert(title: Text("Cart"), message: Text("Successfully added to cart."), dismissButton: .default(Text("Dismiss")))
        })
            .padding(.top)
            .padding(.horizontal, 45)
            .padding(.bottom)
    }
}
