//
//  GrayHatTaskApp.swift
//  GrayHatTask
//
//  Created by Macbook on 31/03/2023.
//

import SwiftUI

@main
struct GrayHatTaskApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
