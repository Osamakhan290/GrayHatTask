//
//  HomeFilterView.swift
//  GrayHatTask
//
//  Created by Macbook on 31/03/2023.
//

import Foundation
import SwiftUI

struct WatchImagesAndTitle: Hashable {
    let title: String
    let imageNames : String
}

struct WatchesView {
    
    let item : [WatchImagesAndTitle] = [
        WatchImagesAndTitle(title: "Apple watch", imageNames: "series1"),
        WatchImagesAndTitle(title: "Galaxy watch", imageNames: "series2"),
        WatchImagesAndTitle(title: "Mix watch", imageNames: "series3"),
        WatchImagesAndTitle(title: "Amaz fit watch", imageNames: "series4")
    ]
}

enum watchesFilterViewModel : Int, CaseIterable {
    case smartWatches
    case casio
    case tisto
    case siko
    
    var title: String {
        switch self {
        
        case .smartWatches:
            return "Smart watch"
        case .casio:
            return "Casio"
        case .tisto:
            return "Tisto"
        case .siko:
            return "Siko"
        }
    }
}


