//
//  HomeView.swift
//  GrayHatTask
//
//  Created by Macbook on 31/03/2023.
//

import SwiftUI



struct HomeView: View {
    @State private var selectedFilter: watchesFilterViewModel = .smartWatches
    @State var viewModel: WatchesView
    @Namespace var animation
    @State private var searchText: String = ""
    @State var title: String = "search product"
    @State var isSearching = false
    @State var gridLayout = [GridItem(.adaptive(minimum: 100)), GridItem(.flexible())]
    
    let watchesSeries = [
        "series1", "series 2", "series 3", "series 7"
    ]
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading){
                    headerContent
                    
                    
                    
                    VStack(alignment: .leading){
                        
                        Text("find your suitabale watch now.")
                            .font(.largeTitle)
                            .fontWeight(.semibold)
                            .frame(width: 300, height: 90)
                    }
                    .padding(30)
                    
                    watchesFilterBar
                    
                    watches
                    
                    
                }
                .padding()
                
                .ignoresSafeArea()
            }
        }
        
        
    }
    
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView(viewModel: WatchesView())
    }
}

extension HomeView {
    
    var headerContent : some View  {
        
        HStack{
            Image(systemName: "line.horizontal.3")
                .resizable()
                .frame(width: 33, height: 22)
            
            Spacer()
            
            HStack{
                
                HStack{
                    TextField(title, text: $searchText)
                }
                .padding(.horizontal, 40)
                .onTapGesture(perform: {
                    isSearching = true
                    
                })
                .overlay(
                    HStack{
                        
                        Image(systemName: "magnifyingglass")
                        Spacer()
                        
                        if isSearching {
                            Button(action: {searchText = ""}, label: {
                                Image(systemName: "xmark.circle.fill")
                                    .foregroundColor(.gray)
                                    .padding()
                            })
                        }
                    }
                    .padding(.horizontal)
                )
                
                
                
            }
            .frame(width:227, height: 51)
            .background(
                Capsule()
                    .strokeBorder(Color.black,lineWidth: 0.8)
                    .background(Color.white)
                    .clipped()
            )
            .clipShape(Capsule())
            
            ForEach(viewModel.item.filter({"\($0)".contains(searchText)}) , id: \.self) { items in
                Text(items.title)
                    .font(.title2)
                    .padding(.horizontal, 10)
                Image(items.imageNames)
                    .resizable()
                    .frame(width: 180, height: 150)
                    .background(Color(.systemGray))
                    .cornerRadius(10)
            }
            
        }
        
    }
    
    var watchesFilterBar: some View {
        HStack{
            ForEach(watchesFilterViewModel.allCases, id: \.rawValue) { item in
                
                VStack{
                    Text(item.title)
                        .font(.subheadline)
                        .fontWeight(selectedFilter == item ? .semibold : .regular)
                        .foregroundColor(selectedFilter == item ? .blue : .gray)
                    
                    if selectedFilter == item {
                        Capsule()
                            .foregroundColor(Color(.systemBlue))
                            .frame(height: 3)
                            .matchedGeometryEffect(id: "filter", in: animation)
                    } else {
                        Capsule()
                            .foregroundColor(Color.clear)
                            .frame(height: 3)
                    }
                }
                .onTapGesture {
                    withAnimation(.easeInOut) {
                        self.selectedFilter = item
                    }
                }
                
            }
        }
    }
    
    
    
    
    var watches: some View{
        
        NavigationLink(
            destination: DetailsView(),
            label: {
                LazyVGrid(columns: gridLayout, alignment: .center, spacing: 20) {
                    ForEach(viewModel.item , id: \.self) { items in
                        VStack(alignment: .leading){
                            Image(items.imageNames)
                                .resizable()
                                .frame(width: 180, height: 150)
                                .background(Color(.systemGray))
                                .cornerRadius(10)
                            
                            VStack(alignment: .leading){
                                Text(items.title)
                                    .font(.title2)
                                    .padding(.horizontal, 10)
                                
                                Text("series 1")
                                    .font(.title3)
                                    .foregroundColor(.gray)
                                    .padding(.top)
                                    .padding(.horizontal, 10)
                                
                                Text("$123")
                                    .font(.title2)
                                    .padding(.horizontal, 10)
                                    .padding(.top)
                                    .padding(.bottom)
                            }
                        }
                        .background(Color(.systemFill))
                        .padding(.top)
                        .cornerRadius(10)
                        
                    }
                }
            })
            .navigationBarHidden(true)
            .foregroundColor(.black)
        
        
        
    }
}
